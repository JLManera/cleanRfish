#' @keywords internal
#' @importFrom utils tail
#' @importFrom data.table :=
#' @importFrom stats time
NULL

# This file is no longer needed - globals are defined in functions.R
# Kept for compatibility
